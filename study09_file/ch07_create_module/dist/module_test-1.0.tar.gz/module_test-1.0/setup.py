from distutils.core import setup
# name 模块名称
# version 版本号
# description 描述
# author 作者
# py_modules 要发布的内容
# setup(name="my_module", version="1.0", description="my module",
# author="lilei", py_modules=['test1.A', 'test1.B', 'test2.C', 'test2.D'])
setup(name="module_test", version="1.0", description="add_diff_printInfo",
author="fengfanli", py_modules=['moduleTest'])
